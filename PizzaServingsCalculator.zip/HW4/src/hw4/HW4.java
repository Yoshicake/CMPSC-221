/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hw4;

/**
 *
 * @author pacma
 */
import javax.swing.*;
public class HW4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PizzaFrame x = new PizzaFrame();
        x.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        x.setSize(350, 300);
        x.setVisible(true);
    }
    
}
